import { courses } from "./courses/data";

const base = "https://ahujanextgen.com";

export default function sitemap() {
  const staticPages = [
    { url: "/", priority: 1, changeFrequency: "weekly" },
    { url: "/computer-courses-shahbad/", priority: 0.95, changeFrequency: "weekly" },
    { url: "/courses/", priority: 0.9, changeFrequency: "weekly" },
  ];

  const coursePages = courses.map((course) => ({
    url: `/courses/${course.slug}/`,
    priority: 0.8,
    changeFrequency: "monthly",
  }));

  return [...staticPages, ...coursePages].map((page) => ({
    url: base + page.url,
    changeFrequency: page.changeFrequency,
    priority: page.priority,
  }));
}
