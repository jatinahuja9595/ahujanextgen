"use client";
import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import {
  Menu, X, ArrowRight, CheckCircle2, Code2, Globe, Calculator,
  BrainCircuit, BarChart3, Award, Sparkles, Phone, Mail, MapPin,
  Clock, Star, Users, Laptop, GraduationCap, Target, Briefcase,
  MessageSquareText, ChevronDown, ChevronRight, Shield,
  Database, Cloud, GitBranch, Lock, LineChart, Bot, MessageCircle, Megaphone, Rocket, BookOpen, Presentation
} from "lucide-react";

/* ---------------------------------------------------------------
   AHUJA NEXTGEN — Skill & Education Academy
   Single-file React app. Client-side "page" state stands in for
   routing so everything lives in one artifact; see the README
   notes at the bottom of the chat reply for how to split this
   into real Next.js routes/pages.
----------------------------------------------------------------*/

const LOGO = "/logo.webp";

const GRAIN = "/grain.png";

const NAVY = "#0A2D6F";
const DEEP = "#050D1F"; // near-black navy — real depth for dark sections, instead of a flat gradient doing all the work

// Get your free Access Key at web3forms.com (enter your email, key is emailed instantly,
// no account needed) and paste it here. Both forms use this one constant.
// Unlike Apps Script, this endpoint URL never changes — nothing to redeploy, nothing that
// can silently break.
const WEB3FORMS_ACCESS_KEY = "fa7fc813-f313-4b14-869e-520ffee54019";

async function submitLead(payload) {
  const res = await fetch("https://api.web3forms.com/submit", {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({
      access_key: WEB3FORMS_ACCESS_KEY,
      subject: "New enquiry: " + (payload.name || "Website visitor"),
      from_name: "Ahuja NextGen Website",
      ...payload,
    }),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data || data.success !== true) {
    throw new Error((data && data.message) || `Server responded with status ${res.status}`);
  }
  return data;
}
const ROYAL = "#1565C0";
const SKY = "#42A5F5";
const GOLD = "#E9A23B"; // added CTA accent — blue-on-blue CTAs disappear, so a warm accent is reserved only for action moments
const INK = "#0B1220";
const PAPER = "#F6F4EF";

const NAV_LINKS = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "programs", label: "Programs" },
  { id: "career", label: "Career Services" },
  { id: "admissions", label: "Admissions" },
  { id: "contact", label: "Contact" },
];

function useReveal() {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold: 0.15 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return [ref, visible];
}

function Reveal({ children, delay = 0, className = "" }) {
  const [ref, visible] = useReveal();
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(18px)",
        transition: `opacity .6s ease ${delay}ms, transform .6s ease ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

function Pill({ children }) {
  return (
    <span
      className="inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-semibold tracking-wide uppercase"
      style={{ background: "rgba(21,101,192,0.08)", color: ROYAL, letterSpacing: "0.08em" }}
    >
      {children}
    </span>
  );
}

function Button({ children, variant = "primary", onClick, icon = true, className = "", type = "button", disabled = false }) {
  const base = "inline-flex items-center justify-center gap-2 rounded-xl px-6 py-3.5 font-semibold text-[15px] transition-all duration-200 whitespace-nowrap";
  const styles = {
    primary: { background: GOLD, color: "#20140a", boxShadow: "0 8px 24px -8px rgba(233,162,59,0.55)" },
    ghost: { background: "transparent", color: "#fff", border: "1.5px solid rgba(255,255,255,0.4)" },
    dark: { background: NAVY, color: "#fff", boxShadow: "0 8px 24px -10px rgba(10,45,111,0.5)" },
    outline: { background: "transparent", color: ROYAL, border: `1.5px solid ${ROYAL}` },
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${base} ${className} hover:-translate-y-0.5 active:translate-y-0 ${disabled ? "opacity-60 pointer-events-none" : ""}`}
      style={styles[variant]}
    >
      {children}
      {icon && <ArrowRight size={16} />}
    </button>
  );
}

function SectionHeading({ eyebrow, title, sub, center = true }) {
  return (
    <Reveal className={`max-w-2xl ${center ? "mx-auto text-center" : ""} mb-14`}>
      {eyebrow && <Pill>{eyebrow}</Pill>}
      <h2
        className="mt-4 font-bold leading-[1.15]"
        style={{ fontFamily: "Fraunces, serif", color: INK, fontSize: "clamp(1.7rem, 3.4vw, 2.6rem)" }}
      >
        {title}
      </h2>
      {sub && <p className="mt-4 text-[15.5px] leading-relaxed" style={{ color: "#5B6474" }}>{sub}</p>}
    </Reveal>
  );
}

/* ---------------- NAVBAR ---------------- */
/* ---------------- BOOK A FREE DEMO — MODAL ---------------- */
function DemoModal({ open, onClose }) {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md rounded-3xl bg-white p-7 shadow-2xl" style={{ boxShadow: "0 30px 80px -20px rgba(10,45,111,0.5)" }}>
        <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center" style={{ background: PAPER, color: "#5B6474" }} aria-label="Close">
          <X size={16} />
        </button>

        {sent ? (
          <div className="py-8 text-center">
            <CheckCircle2 size={40} color={GOLD} className="mx-auto" />
            <div className="mt-4 font-semibold text-[18px]" style={{ color: INK, fontFamily: "Fraunces, serif" }}>Thanks — we've got it.</div>
            <p className="mt-2 text-[13.5px]" style={{ color: "#727C8C" }}>A career counsellor will call you within 24 hours to schedule your free demo class.</p>
            <Button variant="dark" icon={false} onClick={onClose} className="mt-6 w-full">Close</Button>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-2.5 mb-1">
              <GraduationCap size={20} color={GOLD} />
              <span className="text-[12px] font-semibold uppercase tracking-wide" style={{ color: ROYAL }}>Book a Free Demo</span>
            </div>
            <h3 className="font-bold" style={{ fontFamily: "Fraunces, serif", fontSize: "22px", color: INK }}>Which program interests you?</h3>
            <p className="mt-1.5 text-[13px]" style={{ color: "#727C8C" }}>Tell us a bit about you — a counsellor will call to confirm your slot.</p>

            <form
              className="mt-5 space-y-3"
              onSubmit={async (e) => {
                e.preventDefault();
                setError(""); setLoading(true);
                const data = new FormData(e.target);
                const payload = Object.fromEntries(data.entries());
                payload.page = "demo-modal";
                payload.submittedAt = new Date().toISOString();
                try {
                  await submitLead(payload);
                  setSent(true);
                } catch (err) {
                  setError(`Couldn't reach the server (${err.message}). Please call us instead.`);
                } finally {
                  setLoading(false);
                }
              }}
            >
              <input name="name" required placeholder="Full Name" className="h-12 w-full rounded-lg px-4 text-[13.5px] outline-none border transition-all focus:border-[#1565C0] focus:ring-2 focus:ring-[#1565C0]/15" style={{ background: PAPER, color: INK, borderColor: "rgba(10,45,111,0.14)" }} />
              <input name="phone" required placeholder="Phone Number" className="h-12 w-full rounded-lg px-4 text-[13.5px] outline-none border transition-all focus:border-[#1565C0] focus:ring-2 focus:ring-[#1565C0]/15" style={{ background: PAPER, color: INK, borderColor: "rgba(10,45,111,0.14)" }} />
              <select name="course" required defaultValue="" className="h-12 w-full rounded-lg px-4 text-[13.5px] outline-none border transition-all focus:border-[#1565C0] focus:ring-2 focus:ring-[#1565C0]/15" style={{ background: PAPER, color: "#5B6474", borderColor: "rgba(10,45,111,0.14)" }}>
                <option value="" disabled>Which program interests you?</option>
                {PROGRAM_CATS.map((p) => (
                  p.courses.length > 0
                    ? <optgroup key={p.t} label={p.t}>{p.courses.map((c) => <option key={c.name} value={c.name}>{c.name} ({c.duration})</option>)}</optgroup>
                    : <option key={p.t} value={p.t}>{p.t}</option>
                ))}
              </select>
              <select name="preferredTime" defaultValue="" className="h-12 w-full rounded-lg px-4 text-[13.5px] outline-none border transition-all focus:border-[#1565C0] focus:ring-2 focus:ring-[#1565C0]/15" style={{ background: PAPER, color: "#5B6474", borderColor: "rgba(10,45,111,0.14)" }}>
                <option value="">Preferred Batch (optional)</option>
                <option value="Weekday">Weekday</option>
                <option value="Weekend">Weekend</option>
                <option value="Either">Either works</option>
              </select>
              {error && <p className="text-[12.5px]" style={{ color: "#c0392b" }}>{error}</p>}
              <Button type="submit" variant="primary" icon={false} disabled={loading} className="w-full !py-3.5">
                {loading ? "Sending…" : "Get Free Counselling"}
              </Button>
              <p className="text-[11px] text-center" style={{ color: "#9AA3B0" }}>No spam. Just a callback within 24 hours.</p>
            </form>
          </>
        )}
      </div>
    </div>
  );
}

function Navbar({ page, setPage, onOpenDemo }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const go = (id) => { setPage(id); setOpen(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  return (
    <header
      className="sticky top-0 z-50 transition-all duration-300 relative"
      style={{
        background: scrolled ? "rgba(255,255,255,0.92)" : "linear-gradient(180deg, rgba(5,13,31,0.7), rgba(5,13,31,0.4))",
        backdropFilter: "blur(10px)",
        boxShadow: scrolled ? "0 8px 24px -12px rgba(10,45,111,0.25)" : "none",
        borderBottom: "none",
      }}
    >
      {/* Signature gradient hairline — the one consistent premium detail, always present */}
      <div className="absolute bottom-0 left-0 right-0 h-[2px]" style={{ background: `linear-gradient(90deg, ${GOLD}, ${SKY}, ${ROYAL})`, opacity: scrolled ? 1 : 0.7 }} />

      <div className="max-w-7xl mx-auto px-6 lg:px-10 h-20 flex items-center justify-between">
        <button onClick={() => go("home")} className="flex items-center gap-3">
          <div
            className="w-11 h-11 rounded-xl flex items-center justify-center p-1.5 shrink-0"
            style={{
              background: scrolled ? "#fff" : "rgba(255,255,255,0.12)",
              boxShadow: scrolled ? "0 4px 14px -4px rgba(10,45,111,0.3)" : "0 2px 10px -2px rgba(0,0,0,0.2)",
              border: scrolled ? "1px solid rgba(10,45,111,0.08)" : "1px solid rgba(255,255,255,0.2)",
            }}
          >
            <img src={LOGO} alt="Ahuja NextGen logo" className="w-full h-full object-contain" />
          </div>
          <div className="text-left leading-tight">
            <div className="font-bold text-[16px] tracking-tight" style={{ fontFamily: "Fraunces, serif" }}>
              <span style={{ color: scrolled ? NAVY : "#fff" }}>AHUJA</span>{" "}
              <span style={{ color: scrolled ? ROYAL : SKY }}>NEXTGEN</span>
            </div>
            <div className="text-[10px] tracking-widest uppercase font-semibold" style={{ color: scrolled ? "#8892a0" : "rgba(255,255,255,0.65)" }}>
              Skill & Education Academy
            </div>
          </div>
        </button>

        <nav className="hidden lg:flex items-center gap-1">
          {NAV_LINKS.map((l) => (
            <button
              key={l.id}
              onClick={() => go(l.id)}
              className="relative px-4 py-2 text-[14px] font-medium transition-colors group"
              style={{ color: page === l.id ? (scrolled ? ROYAL : "#fff") : (scrolled ? "#48505c" : "rgba(255,255,255,0.85)") }}
            >
              {l.label}
              <span
                className="absolute left-4 right-4 -bottom-0.5 h-[2px] rounded-full transition-transform duration-200 origin-left"
                style={{
                  background: scrolled ? ROYAL : GOLD,
                  transform: page === l.id ? "scaleX(1)" : "scaleX(0)",
                }}
              />
            </button>
          ))}
        </nav>

        <div className="hidden lg:block">
          <Button variant="primary" icon={false} onClick={onOpenDemo} className="!px-5 !py-2.5 !text-[13.5px]">
            Book Free Demo Class
          </Button>
        </div>

        <button className="lg:hidden" onClick={() => setOpen(!open)} style={{ color: scrolled ? INK : "#fff" }}>
          {open ? <X size={26} /> : <Menu size={26} />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden bg-white border-t px-6 py-4 flex flex-col gap-1" style={{ borderColor: "rgba(10,45,111,0.08)" }}>
          {NAV_LINKS.map((l) => (
            <button key={l.id} onClick={() => go(l.id)} className="text-left py-2.5 font-medium" style={{ color: page === l.id ? ROYAL : "#3a4150" }}>
              {l.label}
            </button>
          ))}
          <Button variant="dark" icon={false} onClick={() => { setOpen(false); onOpenDemo(); }} className="mt-2 w-full">Book Free Demo Class</Button>
        </div>
      )}
    </header>
  );
}

/* ---------------- HERO ---------------- */
function Hero({ setPage }) {
  const [heroSent, setHeroSent] = useState(false);
  const [heroLoading, setHeroLoading] = useState(false);
  const [heroError, setHeroError] = useState("");
  return (
    <section className="relative overflow-hidden" style={{ background: `linear-gradient(160deg, ${DEEP} 0%, #0d1c3a 55%, ${NAVY} 100%)` }}>
      {/* ambient network mesh — stands in for a literal classroom photo; suits a "future skills" positioning better than stock imagery */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.16]" viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice">
        {Array.from({ length: 26 }).map((_, i) => {
          const x1 = (i * 137) % 1200, y1 = (i * 251) % 800;
          const x2 = ((i + 6) * 173) % 1200, y2 = ((i + 3) * 197) % 800;
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#fff" strokeWidth="1" />;
        })}
        {Array.from({ length: 26 }).map((_, i) => {
          const cx = (i * 137) % 1200, cy = (i * 251) % 800;
          return <circle key={"c" + i} cx={cx} cy={cy} r="3" fill="#42A5F5" />;
        })}
      </svg>
      {/* subtle dot-grid texture for depth, layered under the glows */}
      <div className="absolute inset-0 opacity-[0.25]" style={{ backgroundImage: "radial-gradient(rgba(255,255,255,0.4) 1px, transparent 1px)", backgroundSize: "28px 28px" }} />
      {/* layered ambient glows — gold now dominant, blue reduced to a single minimal accent */}
      <div className="absolute -top-24 -right-24 w-[420px] h-[420px] rounded-full blur-3xl opacity-[0.22]" style={{ background: GOLD }} />
      <div className="absolute top-1/3 -left-32 w-[320px] h-[320px] rounded-full blur-3xl opacity-[0.16]" style={{ background: "#c97f1f" }} />
      <div className="absolute -bottom-32 right-1/4 w-[380px] h-[380px] rounded-full blur-3xl opacity-[0.1]" style={{ background: SKY }} />

      <div className="relative max-w-7xl mx-auto px-6 lg:px-10 pt-16 pb-28 lg:pt-24 lg:pb-36 grid lg:grid-cols-[1.1fr,0.9fr] gap-14 items-center">
        <div>
          <Reveal>
            <div className="flex flex-wrap items-center gap-3">
              <span className="inline-flex items-center gap-2 text-[13px] font-medium text-white/90 bg-white/10 border border-white/20 rounded-full px-4 py-1.5">
                <Sparkles size={14} color={SKY} /> Admissions Open — Classes Starting Soon
              </span>
              <span className="inline-flex items-center gap-1.5 text-[12px] font-bold text-white bg-white/10 border border-white/20 rounded-full px-3.5 py-1.5">
                <Shield size={13} color={GOLD} fill={GOLD} /> ISO 9001:2015 Certified
              </span>
              <Link href="/computer-courses-shahbad/" className="inline-flex items-center gap-1.5 text-[12px] font-bold text-white bg-white/10 border border-white/20 rounded-full px-3.5 py-1.5 hover:bg-white/15">
                <Laptop size={13} color={SKY} /> Computer Courses in Shahbad
              </Link>
            </div>
          </Reveal>
          <Reveal delay={80}>
            <h1
              className="mt-6 font-bold text-white leading-[1.06]"
              style={{ fontFamily: "Fraunces, serif", fontSize: "clamp(2.4rem, 5vw, 3.6rem)" }}
            >
              Learn{" "}
              <span className="relative inline-block">
                Today.
                <span className="absolute left-0 -bottom-1.5 w-full h-1 rounded-full" style={{ background: GOLD }} />
              </span>
              <br />
              <span
                style={{
                  fontStyle: "italic",
                  fontWeight: 500,
                  background: `linear-gradient(90deg, #fff, ${SKY})`,
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                  color: "transparent",
                }}
              >
                Lead Tomorrow.
              </span>
            </h1>
          </Reveal>
          <Reveal delay={160}>
            <p className="mt-6 text-[17px] leading-relaxed text-white/80 max-w-lg">
              Practical computer and career skills in Shahbad, Haryana — designed to help you learn, practise, and confidently work independently, from your first computer lesson to your first job opportunity.
            </p>
          </Reveal>
          <Reveal delay={200}>
            {/* Tagline strip from the logo: Learn is the confirmed primary tagline; Grow / Succeed are placeholders until final copy is provided */}
            <div className="mt-5 flex items-center gap-3">
              <span className="flex items-center gap-1.5 text-[13px] font-bold tracking-[0.12em] text-white">
                <GraduationCap size={16} color={GOLD} /> LEARN
              </span>
              <span className="w-1 h-1 rounded-full bg-white/30" />
              <span className="text-[13px] font-semibold tracking-[0.12em] text-white/40">GROW</span>
              <span className="w-1 h-1 rounded-full bg-white/30" />
              <span className="text-[13px] font-semibold tracking-[0.12em] text-white/40">SUCCEED</span>
            </div>
          </Reveal>
          <Reveal delay={240}>
            <div className="mt-9 flex flex-wrap gap-4">
              <Button variant="primary" onClick={() => setPage("programs")}>Explore Programs</Button>
              <Button variant="ghost" onClick={() => setPage("admissions")}>Apply Now</Button>
            </div>
          </Reveal>
          <Reveal delay={320}>
            <div className="mt-12 flex flex-wrap gap-x-10 gap-y-4">
              {[["12+", "Career-Ready Programs"], ["2", "Free Demo Classes"], ["15%", "Early Bird Discount"]].map(([n, l]) => (
                <div key={l}>
                  <div className="text-2xl font-bold text-white" style={{ fontFamily: "Fraunces, serif" }}>{n}</div>
                  <div className="text-[12.5px] text-white/65">{l}</div>
                </div>
              ))}
            </div>
          </Reveal>
        </div>

        <Reveal delay={200}>
          <div className="relative mx-auto max-w-sm">
            {/* glow ring behind the card — the "it pops off the screen" detail */}
            <div className="absolute -inset-4 rounded-[2rem] blur-2xl opacity-40" style={{ background: `linear-gradient(135deg, ${GOLD}, ${SKY})` }} />
            <div className="relative rounded-3xl p-6 backdrop-blur-md" style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.18)" }}>
              <div className="rounded-2xl bg-white p-6 shadow-2xl">
                {heroSent ? (
                  <div className="py-6 text-center">
                    <CheckCircle2 size={32} color={GOLD} className="mx-auto" />
                    <div className="mt-3 font-semibold text-[14px]" style={{ color: INK }}>Thanks — we've got it.</div>
                    <p className="mt-1 text-[12.5px]" style={{ color: "#727C8C" }}>A career counsellor will call you within 24 hours.</p>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center justify-between mb-5">
                      <span className="text-[12px] font-semibold uppercase tracking-wide" style={{ color: ROYAL }}>Book a Free Demo</span>
                      <GraduationCap size={20} color={GOLD} />
                    </div>
                    <form
                      className="space-y-3"
                      onSubmit={async (e) => {
                        e.preventDefault();
                        setHeroError(""); setHeroLoading(true);
                        const data = new FormData(e.target);
                        const payload = Object.fromEntries(data.entries());
                        payload.page = "home-hero";
                        payload.submittedAt = new Date().toISOString();
                        try {
                          await submitLead(payload);
                          setHeroSent(true);
                        } catch (err) {
                          setHeroError(`Couldn't reach the server (${err.message}).`);
                        } finally {
                          setHeroLoading(false);
                        }
                      }}
                    >
                      <input name="name" required placeholder="Full Name" className="h-11 w-full rounded-lg px-3.5 text-[13.5px] outline-none border transition-all focus:border-[#1565C0] focus:ring-2 focus:ring-[#1565C0]/15" style={{ background: PAPER, color: INK, borderColor: "rgba(10,45,111,0.14)" }} />
                      <input name="phone" required placeholder="Phone Number" className="h-11 w-full rounded-lg px-3.5 text-[13.5px] outline-none border transition-all focus:border-[#1565C0] focus:ring-2 focus:ring-[#1565C0]/15" style={{ background: PAPER, color: INK, borderColor: "rgba(10,45,111,0.14)" }} />
                      <select name="course" defaultValue="" className="h-11 w-full rounded-lg px-3.5 text-[13.5px] outline-none border transition-all focus:border-[#1565C0] focus:ring-2 focus:ring-[#1565C0]/15" style={{ background: PAPER, color: "#5B6474", borderColor: "rgba(10,45,111,0.14)" }}>
                        <option value="">Course of Interest</option>
                        {PROGRAM_CATS.map((p) => (
                          p.courses.length > 0
                            ? <optgroup key={p.t} label={p.t}>{p.courses.map((c) => <option key={c.name} value={c.name}>{c.name} ({c.duration})</option>)}</optgroup>
                            : <option key={p.t} value={p.t}>{p.t}</option>
                        ))}
                      </select>
                      {heroError && <p className="text-[11.5px]" style={{ color: "#c0392b" }}>{heroError}</p>}
                      <button type="submit" disabled={heroLoading} className="mt-1 w-full h-11 rounded-lg font-semibold text-[14px] text-white disabled:opacity-60" style={{ background: `linear-gradient(90deg, ${DEEP}, ${NAVY})` }}>
                        {heroLoading ? "Sending…" : "Get Free Counselling"}
                      </button>
                    </form>
                    <p className="mt-3 text-[11px] text-center" style={{ color: "#9AA3B0" }}>No spam. Just a callback within 24 hours.</p>
                  </>
                )}
              </div>
            </div>
          </div>
        </Reveal>
      </div>

      {/* angled divider — bridges into the next (light) section instead of a hard flat cut */}
      <svg className="absolute bottom-0 left-0 w-full" viewBox="0 0 1440 60" preserveAspectRatio="none" style={{ height: "48px" }}>
        <path d="M0,60 L1440,20 L1440,60 Z" fill={PAPER} />
      </svg>
    </section>
  );
}

/* ---------------- WHY CHOOSE ---------------- */
const WHY_SHOWCASE = [
  { icon: Laptop, t: "Certificate Se Pehle Confidence", d: "Course karna alag hai. Computer par independently kaam karna alag. We start with the basics, give you guided practice, and help you build the confidence to solve everyday computer tasks yourself." },
  { icon: Award, t: "Placement & Interview Guidance", d: "Get practical career support through resume creation, interview preparation, career counselling and placement assistance. We help you prepare for the next step without promising a job guarantee." },
  { icon: Sparkles, t: "Emerging Technology Tracks", d: "AI, cloud, cybersecurity, data analytics — the curriculum gets updated as the market moves, instead of teaching the same syllabus for five years straight." },
];
const WHY_MORE = [
  { icon: Briefcase, t: "Industry-Oriented Curriculum" },
  { icon: Users, t: "Experienced Trainers, Small Batches" },
  { icon: Laptop, t: "Modern Computer Lab" },
  { icon: Presentation, t: "Industry Expert Sessions (Online & Offline)" },
  { icon: Clock, t: "Weekday & Weekend Batches" },
  { icon: MessageSquareText, t: "1:1 Career Counselling" },
  { icon: CheckCircle2, t: "Certification on Completion" },
];

function WhyChoose() {
  return (
    <section className="py-24 px-6 lg:px-10 relative overflow-hidden bg-white">
      <div className="max-w-6xl mx-auto">
        <SectionHeading eyebrow="Why AHUJA NEXTGEN" title="Built for how careers actually get started" sub="Every element of the academy — batch size, trainers, lab time, and mentorship — is designed around one outcome: you, hireable." />

        <div className="space-y-16 lg:space-y-24">
          {WHY_SHOWCASE.map((w, i) => {
            const reversed = i % 2 === 1;
            const textBlock = (
              <div key="text">
                <div className="text-[13px] font-bold tracking-widest uppercase mb-3" style={{ color: GOLD }}>0{i + 1}</div>
                <h3 className="font-bold leading-tight" style={{ fontFamily: "Fraunces, serif", fontSize: "clamp(1.5rem, 2.6vw, 2.1rem)", color: INK }}>{w.t}</h3>
                <p className="mt-4 text-[15px] leading-relaxed max-w-md" style={{ color: "#5B6474" }}>{w.d}</p>
              </div>
            );
            const graphicBlock = (
              <div key="graphic" className="relative aspect-[4/3] rounded-3xl overflow-hidden flex items-center justify-center" style={{ background: `linear-gradient(135deg, ${DEEP}, ${NAVY})` }}>
                <div className="absolute -top-10 -left-10 w-40 h-40 rounded-full blur-3xl opacity-25" style={{ background: SKY }} />
                <div className="absolute -bottom-14 -right-14 w-56 h-56 rounded-full blur-3xl opacity-20" style={{ background: GOLD }} />
                <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: "radial-gradient(rgba(255,255,255,0.9) 1px, transparent 1px)", backgroundSize: "22px 22px" }} />
                <w.icon size={72} color="rgba(255,255,255,0.9)" strokeWidth={1.2} className="relative" />
              </div>
            );
            return (
              <Reveal key={w.t} delay={i * 100}>
                <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
                  {reversed ? [graphicBlock, textBlock] : [textBlock, graphicBlock]}
                </div>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={200}>
          <div className="mt-20 pt-14 border-t" style={{ borderColor: "rgba(10,45,111,0.08)" }}>
            <div className="text-[12px] font-semibold uppercase tracking-wide mb-6" style={{ color: ROYAL }}>Plus everything else you'd expect</div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
              {WHY_MORE.map((w) => (
                <div key={w.t} className="flex items-center gap-3">
                  <w.icon size={17} color={ROYAL} className="shrink-0" />
                  <span className="text-[14px]" style={{ color: "#3a4150" }}>{w.t}</span>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ---------------- CAREER JOURNEY (signature element) ---------------- */
const JOURNEY = [
  { t: "Learn", d: "Concepts taught with real tools, not just slides." },
  { t: "Practice", d: "Guided lab hours to build muscle memory." },
  { t: "Build Projects", d: "Portfolio-ready work you can show employers." },
  { t: "Get Certified", d: "Assessed, verified, and certificate-ready." },
  { t: "Interview Prep", d: "Mock interviews and resume polishing." },
  { t: "Career Success", d: "Placement support until you're hired." },
];

function CareerJourney() {
  return (
    <section className="relative py-24 px-6 lg:px-10 bg-white overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] rounded-full blur-3xl opacity-[0.04]" style={{ background: ROYAL }} />
      <div className="relative max-w-7xl mx-auto">
        <SectionHeading eyebrow="The Path" title="Your career journey, mapped step by step" sub="This is the actual sequence every learner moves through — nothing skipped, nothing rushed." />
        <div className="relative">
          <div className="hidden lg:block absolute top-[38px] left-[6%] right-[6%] h-[2px]" style={{ background: `linear-gradient(90deg, ${NAVY}, ${SKY})` }} />
          <div className="grid lg:grid-cols-6 gap-8 lg:gap-4">
            {JOURNEY.map((j, i) => {
              const isLast = i === JOURNEY.length - 1;
              return (
                <Reveal key={j.t} delay={i * 90}>
                  <div className="relative flex lg:flex-col items-start lg:items-center gap-4 lg:gap-0 lg:text-center">
                    <div
                      className="relative z-10 w-[76px] h-[76px] shrink-0 rounded-2xl flex items-center justify-center font-bold text-white text-lg lg:mb-5"
                      style={{ background: isLast ? `linear-gradient(135deg, ${GOLD}, #c97f1f)` : `linear-gradient(135deg, ${DEEP}, ${NAVY})`, fontFamily: "Fraunces, serif", boxShadow: isLast ? "0 8px 20px -6px rgba(233,162,59,0.5)" : "0 4px 14px -4px rgba(10,45,111,0.35)" }}
                    >
                      {isLast ? <Award size={26} /> : `0${i + 1}`}
                    </div>
                    <div>
                      <div className="font-semibold text-[15px]" style={{ color: INK, fontFamily: "Fraunces, serif" }}>{j.t}</div>
                      <p className="mt-1.5 text-[13px] leading-relaxed" style={{ color: "#727C8C" }}>{j.d}</p>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------------- ADMISSIONS STRIP ---------------- */
function AdmissionsStrip({ setPage }) {
  const items = ["Free 2 Demo Classes", "Free Career Counselling", "15% Early Bird Discount", "Weekday & Weekend Batches", "Limited Seats"];
  return (
    <section className="relative py-20 px-6 lg:px-10 overflow-hidden" style={{ background: `linear-gradient(120deg, ${DEEP}, ${NAVY})` }}>
      {/* angled top edge — bridges from the white section above instead of a hard flat cut */}
      <svg className="absolute top-0 left-0 w-full" viewBox="0 0 1440 40" preserveAspectRatio="none" style={{ height: "32px" }}>
        <path d="M0,0 L1440,0 L1440,10 L0,32 Z" fill="#fff" />
      </svg>
      <div className="absolute -top-10 left-1/4 w-64 h-64 rounded-full blur-3xl opacity-[0.15]" style={{ background: GOLD }} />
      <div className="absolute -bottom-16 right-1/5 w-72 h-72 rounded-full blur-3xl opacity-[0.12]" style={{ background: SKY }} />
      <div className="relative max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-8">
        <Reveal>
          <h3 className="text-white font-bold text-[26px]" style={{ fontFamily: "Fraunces, serif" }}>Admissions Open — Classes Starting Soon</h3>
          <div className="mt-4 flex flex-wrap gap-x-6 gap-y-2">
            {items.map((it) => (
              <span key={it} className="flex items-center gap-1.5 text-[13.5px] text-white/85">
                <CheckCircle2 size={15} color={GOLD} /> {it}
              </span>
            ))}
          </div>
        </Reveal>
        <Reveal delay={120}>
          <Button variant="primary" onClick={() => setPage("admissions")}>Reserve Your Seat</Button>
        </Reveal>
      </div>
      {/* angled bottom edge — bridges into the white section below */}
      <svg className="absolute bottom-0 left-0 w-full" viewBox="0 0 1440 40" preserveAspectRatio="none" style={{ height: "32px" }}>
        <path d="M0,8 L1440,0 L1440,40 L0,40 Z" fill="#fff" />
      </svg>
    </section>
  );
}

/* ---------------- WHO CAN JOIN ---------------- */
function WhoCanJoin() {
  const who = [
    { icon: GraduationCap, t: "School Students" },
    { icon: Users, t: "College Students" },
    { icon: Briefcase, t: "Job Seekers" },
    { icon: LineChart, t: "Working Professionals" },
    { icon: Sparkles, t: "Upskillers" },
    { icon: Target, t: "Career Switchers" },
    { icon: Rocket, t: "Entrepreneurs & Business Owners" },
    { icon: BookOpen, t: "Competitive Exam Aspirants" },
  ];
  return (
    <section className="py-24 px-6 lg:px-10 relative overflow-hidden" style={{ background: PAPER }}>
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[500px] h-[220px] rounded-full blur-3xl opacity-[0.06]" style={{ background: GOLD }} />
      <div className="relative max-w-4xl mx-auto text-center">
        <SectionHeading eyebrow="Who It's For" title="Wherever you're starting from, there's a track for you" />
        <div className="flex flex-wrap justify-center gap-3">
          {who.map((w, i) => (
            <Reveal key={w.t} delay={i * 50} className="inline-block">
              <div
                className="group flex items-center gap-2.5 rounded-full pl-4 pr-5 py-3 bg-white hover:-translate-y-0.5 transition-all duration-200"
                style={{ boxShadow: "0 2px 10px -4px rgba(10,45,111,0.1)", border: "1px solid rgba(10,45,111,0.06)" }}
              >
                <w.icon size={17} color={ROYAL} className="shrink-0" />
                <span className="text-[14px] font-medium" style={{ color: INK }}>{w.t}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- PROGRAM CATEGORIES (shared data) ---------------- */
const PROGRAM_CATS = [
  {
    icon: Laptop, t: "Foundational", d: "MS Office, internet & digital literacy, typing fluency.",
    duration: "2 Months – 1 Year",
    outcomes: ["Confident daily computer use", "MS Word, Excel, PowerPoint", "Email & internet literacy"],
    careers: ["Office Assistant", "Data Entry Operator", "Admin Support"],
    courses: [
      { name: "Basic Computer Course", duration: "2 Months" },
      { name: "Awareness in Computer Concepts", duration: "3 Months" },
      { name: "Course on Computer Concepts", duration: "4 Months" },
      { name: "Advance Course on Computer Concepts", duration: "5 Months" },
      { name: "Expert Computer Course", duration: "6 Months" },
      { name: "Advance Computer Concepts and Programming", duration: "1 Year" },
    ],
  },
  {
    icon: Code2, t: "Coding & Programming", d: "C, C++, Python, Java — the logic behind every application.",
    duration: "2 Months – 1 Year",
    outcomes: ["Strong programming fundamentals", "Problem-solving with code", "Portfolio of small projects"],
    careers: ["Junior Developer", "QA Engineer", "Trainee Programmer"],
    courses: [
      { name: "Coding Foundation (C, C++, Python basics)", duration: "3 Months" },
      { name: "C Language Programming", duration: "2 Months" },
      { name: "C++ Language Programming", duration: "2 Months" },
      { name: "Programming with Python", duration: "3 Months" },
      { name: "Java Programming (Basic to Advanced)", duration: "3 Months" },
      { name: "Data Structure and Algorithm", duration: "3 Months" },
      { name: "Course in Software Development", duration: "1 Year" },
    ],
  },
  {
    icon: Globe, t: "Web Development", d: "HTML, CSS, JavaScript, PHP & MySQL — build and ship real websites.",
    duration: "2 Months – 1 Year",
    outcomes: ["Responsive site development", "Frontend + backend basics", "A live portfolio site"],
    careers: ["Web Developer", "Frontend Developer", "Freelance Web Builder"],
    courses: [
      { name: "Web Development Starter", duration: "2 Months" },
      { name: "PHP and MySQL Web Development", duration: "3 Months" },
      { name: "Course in Web Technology", duration: "1 Year" },
      { name: "Professional Programming & Web Development", duration: "1 Year" },
    ],
  },
  {
    icon: BrainCircuit, t: "AI / ML", d: "AI concepts, prompt engineering, and applied machine learning.",
    duration: "2 Months – 1 Year",
    outcomes: ["Core AI/ML concepts", "Hands-on AI tools & prompt engineering", "Applied mini-projects"],
    careers: ["AI Associate", "Automation Analyst", "AI Tools Specialist", "ML Engineer"],
    courses: [
      { name: "Prompt Engineering", duration: "2 Months" },
      { name: "Computational Thinking and Artificial Intelligence", duration: "2 Months" },
      { name: "Artificial Intelligence Fundamentals", duration: "3 Months" },
      { name: "Machine Learning Basic", duration: "6 Months" },
      { name: "AI Application Development", duration: "6 Months" },
      { name: "Machine Learning Advanced", duration: "9 Months" },
      { name: "AI Engineering & Deep Learning", duration: "1 Year" },
    ],
  },
  {
    icon: Calculator, t: "Accounting", d: "Tally, GST, and practical bookkeeping for real businesses.",
    duration: "3 Months – 1 Year",
    outcomes: ["Tally Prime proficiency", "GST-ready invoicing", "Ledger & balance sheets"],
    careers: ["Accounts Assistant", "Billing Executive", "Bookkeeper"],
    courses: [
      { name: "Professional Financial Accounting", duration: "3 Months" },
      { name: "Tally Prime Course", duration: "3 Months" },
      { name: "Certificate Course in Computer Basics and Accounting", duration: "6 Months" },
      { name: "Certificate Data Entry and Office Assistant", duration: "6 Months" },
      { name: "Course in Digital Accounting", duration: "1 Year" },
      { name: "Office Automation, Accounting and Publishing Assistant", duration: "1 Year" },
    ],
  },
  {
    icon: Megaphone, t: "Digital Marketing", d: "SEO, social media, and campaign fundamentals for real businesses.",
    duration: "3 – 6 Months",
    outcomes: ["Core digital marketing channels", "Campaign planning basics", "Practical hands-on tools"],
    careers: ["Digital Marketing Executive", "Social Media Associate"],
    courses: [
      { name: "Basic Digital Marketing", duration: "3 Months" },
      { name: "Advanced Digital Marketing", duration: "6 Months" },
    ],
  },
  {
    icon: BarChart3, t: "Data Analytics", d: "Turning raw data into decisions with real analytical tools.",
    duration: "3 – 6 Months",
    outcomes: ["Data cleaning & analysis", "Dashboards & reporting", "Data-driven decision making"],
    careers: ["Data Analyst", "Reporting Executive", "BI Associate"],
    courses: [
      { name: "Basic Data Analysis", duration: "3 Months" },
      { name: "Advanced Data Analysis", duration: "6 Months" },
    ],
  },
  {
    icon: Sparkles, t: "Emerging Technologies", d: "SQL, Cloud, DevOps, Product Management & Graphic Design.",
    duration: "2 – 3 Months",
    outcomes: ["Market-relevant tooling", "Cloud & DevOps basics", "Hands-on, practical modules"],
    careers: ["Cloud Support Associate", "DevOps Trainee", "Junior Product Analyst"],
    courses: [
      { name: "SQL", duration: "2 Months" },
      { name: "Cloud Fundamentals", duration: "2 Months" },
      { name: "Product Management", duration: "3 Months" },
      { name: "DevOps Fundamentals", duration: "2 Months" },
      { name: "Graphic Designing", duration: "2 Months" },
    ],
  },
];

function ProgramsOverview({ setPage, goToEnquiry }) {
  return (
    <section className="py-24 px-6 lg:px-10" style={{ background: PAPER }}>
      <div className="max-w-7xl mx-auto">
        <SectionHeading eyebrow="Programs" title="Career tracks across every in-demand skill" sub="New programs are introduced regularly based on market demand and emerging technologies." />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {PROGRAM_CATS.map((p, i) => (
            <Reveal key={p.t} delay={i * 50}>
              <div
                className="group relative h-full rounded-2xl bg-white p-6 flex flex-col overflow-hidden hover:-translate-y-1.5 transition-all duration-300"
                style={{ boxShadow: "0 2px 16px -6px rgba(10,45,111,0.08)" }}
                onMouseEnter={(e) => { e.currentTarget.style.boxShadow = "0 18px 36px -14px rgba(10,45,111,0.3)"; }}
                onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "0 2px 16px -6px rgba(10,45,111,0.08)"; }}
              >
                <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-2xl" style={{ background: SKY }} />
                <div className="absolute top-0 left-0 right-0 h-[3px] scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-300" style={{ background: `linear-gradient(90deg, ${GOLD}, ${SKY})` }} />
                <div className="relative w-11 h-11 rounded-xl flex items-center justify-center mb-4 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3" style={{ background: `linear-gradient(135deg, ${DEEP}, ${NAVY})`, boxShadow: "0 6px 16px -6px rgba(10,45,111,0.4)" }}>
                  <p.icon size={20} color="#fff" />
                </div>
                <div className="relative font-semibold text-[15.5px]" style={{ color: INK, fontFamily: "Fraunces, serif" }}>{p.t}</div>
                <p className="relative mt-2 text-[13px] leading-relaxed flex-1" style={{ color: "#727C8C" }}>{p.d}</p>
                <button onClick={() => goToEnquiry(p.t)} className="relative mt-4 flex items-center gap-1 text-[13px] font-semibold group/btn" style={{ color: ROYAL }}>
                  Enquire Now <ChevronRight size={14} className="transition-transform duration-200 group-hover/btn:translate-x-1" />
                </button>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------------- CONTACT FORM (shared) ---------------- */
function ContactBlock({ dark = false, initialCourse = "" }) {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [course, setCourse] = useState(initialCourse);
  const address = "Ekta Vihar, Near City Heart School, Shahabad Markanda, Distt. Kurukshetra";
  // Exact GPS coordinates captured on-site (GPS Map Camera), more precise than an address search
  const LAT = 30.163771, LNG = 76.866365;
  const mapsLink = `https://maps.google.com/?q=${LAT},${LNG}`;

  const fieldStyle = {
    background: dark ? "rgba(255,255,255,0.08)" : "#fff",
    color: dark ? "#fff" : INK,
    border: dark ? "1px solid rgba(255,255,255,0.14)" : "1px solid rgba(10,45,111,0.14)",
  };
  const focusClass = dark
    ? "focus:border-white/50 focus:ring-2 focus:ring-white/20"
    : "focus:border-[#1565C0] focus:ring-2 focus:ring-[#1565C0]/15";
  const labelClass = "block mb-1.5 text-[12px] font-semibold";

  return (
    <div className="grid lg:grid-cols-2 gap-10">
      <div>
        <div className="grid sm:grid-cols-2 gap-4">
          {[
            { icon: Phone, t: "Call Us", lines: [["+91 90346 40741", "tel:+919034640741"], ["+91 94662 41741", "tel:+919466241741"]] },
            { icon: Mail, t: "Email Us", lines: [["ahujanextgen@gmail.com", "mailto:ahujanextgen@gmail.com"]] },
            { icon: MapPin, t: "Visit Us", lines: [[address, mapsLink]], external: true },
            { icon: Clock, t: "Working Hours", lines: [["Mon–Sat, 9:00 AM – 7:00 PM", null]] },
          ].map((c) => (
            <div key={c.t} className="rounded-2xl p-5" style={{ background: dark ? "rgba(255,255,255,0.06)" : PAPER, border: dark ? "1px solid rgba(255,255,255,0.1)" : "1px solid rgba(10,45,111,0.06)" }}>
              <div className="flex items-center gap-2.5 mb-3">
                <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0" style={{ background: dark ? "rgba(255,255,255,0.1)" : "rgba(21,101,192,0.1)" }}>
                  <c.icon size={16} color={dark ? SKY : ROYAL} />
                </div>
                <div className="font-semibold text-[13px]" style={{ color: dark ? "#fff" : INK }}>{c.t}</div>
              </div>
              <div className="space-y-1">
                {c.lines.map(([text, href], i) => (
                  href ? (
                    <a key={i} href={href} target={c.external ? "_blank" : undefined} rel={c.external ? "noopener noreferrer" : undefined} className="block text-[13px] leading-relaxed hover:underline" style={{ color: dark ? "rgba(255,255,255,0.75)" : "#5B6474" }}>
                      {text}
                    </a>
                  ) : (
                    <div key={i} className="text-[13px] leading-relaxed" style={{ color: dark ? "rgba(255,255,255,0.75)" : "#5B6474" }}>{text}</div>
                  )
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-5 rounded-2xl overflow-hidden h-48 relative" style={{ border: dark ? "1px solid rgba(255,255,255,0.12)" : "1px solid rgba(10,45,111,0.08)" }}>
          <iframe
            title="Ahuja NextGen location map"
            src={`https://maps.google.com/maps?q=${LAT},${LNG}&z=16&output=embed`}
            width="100%"
            height="100%"
            style={{ border: 0 }}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
        <a
          href={mapsLink}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-2 inline-flex items-center gap-1.5 text-[12.5px] font-medium hover:underline"
          style={{ color: dark ? SKY : ROYAL }}
        >
          <MapPin size={13} /> Get directions on Google Maps
        </a>
      </div>

      <div className="rounded-2xl p-7" style={{ background: dark ? "rgba(255,255,255,0.06)" : "#fff", border: dark ? "1px solid rgba(255,255,255,0.12)" : "1px solid rgba(10,45,111,0.08)", boxShadow: dark ? "none" : "0 4px 24px -8px rgba(10,45,111,0.1)" }}>
        {sent ? (
          <div className="h-full flex flex-col items-center justify-center text-center py-10">
            <CheckCircle2 size={38} color={GOLD} />
            <div className="mt-4 font-semibold text-[16px]" style={{ color: dark ? "#fff" : INK }}>Thanks — we've got your enquiry.</div>
            <p className="mt-1 text-[13.5px]" style={{ color: dark ? "rgba(255,255,255,0.7)" : "#727C8C" }}>A career counsellor will call you within 24 hours.</p>
          </div>
        ) : (
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setError(""); setLoading(true);
              const data = new FormData(e.target);
              const payload = Object.fromEntries(data.entries());
              payload.page = window.location.pathname;
              payload.submittedAt = new Date().toISOString();
              try {
                await submitLead(payload);
                setSent(true);
              } catch (err) {
                setError(`Couldn't reach the server (${err.message}). Please call us instead.`);
              } finally {
                setLoading(false);
              }
            }}
            className="space-y-4"
          >
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className={labelClass} style={{ color: dark ? "rgba(255,255,255,0.7)" : "#5B6474" }}>Full Name</label>
                <input name="name" required placeholder="e.g. Priya Sharma" className={`h-12 w-full rounded-lg px-4 text-[13.5px] outline-none transition-all ${focusClass}`} style={fieldStyle} />
              </div>
              <div>
                <label className={labelClass} style={{ color: dark ? "rgba(255,255,255,0.7)" : "#5B6474" }}>Phone Number</label>
                <input name="phone" required placeholder="10-digit mobile number" className={`h-12 w-full rounded-lg px-4 text-[13.5px] outline-none transition-all ${focusClass}`} style={fieldStyle} />
              </div>
            </div>
            <div>
              <label className={labelClass} style={{ color: dark ? "rgba(255,255,255,0.7)" : "#5B6474" }}>Email Address</label>
              <input name="email" type="email" placeholder="you@example.com" className={`h-12 w-full rounded-lg px-4 text-[13.5px] outline-none transition-all ${focusClass}`} style={fieldStyle} />
            </div>
            <div>
              <label className={labelClass} style={{ color: dark ? "rgba(255,255,255,0.7)" : "#5B6474" }}>Course of Interest</label>
              <select name="course" value={course} onChange={(e) => setCourse(e.target.value)} className={`h-12 w-full rounded-lg px-4 text-[13.5px] outline-none transition-all ${focusClass}`} style={fieldStyle}>
                <option value="">Select a course</option>
                {PROGRAM_CATS.map((p) => (
                  p.courses.length > 0 ? (
                    <optgroup key={p.t} label={p.t}>
                      {p.courses.map((c) => <option key={c.name} value={c.name}>{c.name} ({c.duration})</option>)}
                    </optgroup>
                  ) : (
                    <option key={p.t} value={p.t}>{p.t}</option>
                  )
                ))}
              </select>
            </div>
            <div>
              <label className={labelClass} style={{ color: dark ? "rgba(255,255,255,0.7)" : "#5B6474" }}>Message (optional)</label>
              <textarea name="message" placeholder="Anything specific you'd like to ask?" rows={3} className={`w-full rounded-lg px-4 py-3 text-[13.5px] outline-none resize-none transition-all ${focusClass}`} style={fieldStyle} />
            </div>
            {error && <p className="text-[12.5px]" style={{ color: "#c0392b" }}>{error}</p>}
            <Button type="submit" variant="primary" icon={false} disabled={loading} className="w-full !py-3.5">{loading ? "Sending…" : "Send Enquiry"}</Button>
            <p className="text-[11px] text-center" style={{ color: dark ? "rgba(255,255,255,0.5)" : "#9AA3B0" }}>We typically respond within 24 hours.</p>
          </form>
        )}
      </div>
    </div>
  );
}

/* ---------------- FOOTER ---------------- */
function Footer({ setPage }) {
  return (
    <footer style={{ background: INK }} className="pt-16 pb-8 px-6 lg:px-10">
      <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-10 pb-10 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2.5">
            <img src={LOGO} alt="Ahuja NextGen logo" className="w-10 h-10 rounded-lg object-contain" style={{ background: "#fff" }} />
            <span className="font-bold text-white" style={{ fontFamily: "Fraunces, serif" }}>AHUJA NEXTGEN</span>
          </div>
          <p className="mt-4 text-[13px] leading-relaxed text-white/65">Empowering minds. Shaping futures. A modern skill & technology academy for career-ready learners.</p>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 text-[11.5px] font-bold text-white/70 border border-white/15 rounded-full px-3 py-1.5">
              <Shield size={12} color={GOLD} fill={GOLD} /> ISO 9001:2015 Certified
            </span>
            <a
              href="https://instagram.com/ahuja_nextgen"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-[11.5px] font-bold text-white/70 border border-white/15 rounded-full px-3 py-1.5 hover:text-white hover:border-white/30 transition-colors"
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="3" width="18" height="18" rx="5" stroke="currentColor" strokeWidth="2"/><circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="2"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor"/></svg> @ahuja_nextgen
            </a>
          </div>
        </div>
        <div>
          <div className="text-white font-semibold text-[13px] uppercase tracking-wide mb-4">Quick Links</div>
          <div className="flex flex-col gap-2.5">
            {NAV_LINKS.map((l) => <button key={l.id} onClick={() => setPage(l.id)} className="text-left text-[13.5px] text-white/55 hover:text-white transition-colors">{l.label}</button>)}
          </div>
        </div>
        <div>
          <div className="text-white font-semibold text-[13px] uppercase tracking-wide mb-4">Programs</div>
          <div className="flex flex-col gap-2.5">
            {PROGRAM_CATS.slice(0, 5).map((p) => <span key={p.t} className="text-[13.5px] text-white/55">{p.t}</span>)}
            <Link href="/computer-courses-shahbad/" className="text-[13.5px] text-white/80 hover:text-white transition-colors">Computer Courses in Shahbad →</Link>
            <Link href="/courses/" className="text-[13.5px] text-white/80 hover:text-white transition-colors">All Courses →</Link>
          </div>
        </div>
        <div>
          <div className="text-white font-semibold text-[13px] uppercase tracking-wide mb-4">Contact</div>
          <div className="flex flex-col gap-2.5 text-[13.5px] text-white/55">
            <a href="tel:+919034640741" className="hover:text-white transition-colors">+91 90346 40741</a>
            <a href="tel:+919466241741" className="hover:text-white transition-colors">+91 94662 41741</a>
            <a href="mailto:ahujanextgen@gmail.com" className="hover:text-white transition-colors">ahujanextgen@gmail.com</a>
            <a href="https://maps.google.com/?q=30.163771,76.866365" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Ekta Vihar, Near City Heart School, Shahabad Markanda, Distt. Kurukshetra</a>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-[12.5px] text-white/60">
        <span>© {new Date().getFullYear()} Ahuja NextGen. All rights reserved.</span>
        <div className="flex gap-5">
          <span>Privacy Policy</span>
          <span>Terms</span>
        </div>
      </div>
    </footer>
  );
}

function StatementBlock({ setPage }) {
  return (
    <section className="relative py-28 px-6 lg:px-10 overflow-hidden" style={{ background: DEEP }}>
      <div className="absolute inset-0 opacity-[0.4]" style={{ backgroundImage: `url(${GRAIN})`, backgroundSize: "128px 128px" }} />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] rounded-full blur-3xl opacity-[0.12]" style={{ background: ROYAL }} />
      <div className="relative max-w-3xl mx-auto text-center">
        <Reveal>
          <div className="text-6xl leading-none mb-4" style={{ color: GOLD, fontFamily: "Fraunces, serif" }}>"</div>
          <p
            className="font-medium text-white leading-snug"
            style={{ fontFamily: "Fraunces, serif", fontStyle: "italic", fontSize: "clamp(1.6rem, 3.4vw, 2.4rem)" }}
          >
            We didn't set out to build another coaching class. We set out to build the bridge between where you are right now and the job you actually want.
          </p>
          <div className="mt-9">
            <Button variant="primary" onClick={() => setPage("admissions")}>Start Your Journey</Button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ================= PAGES ================= */


function IndependenceSection({ setPage }) {
  const steps = [
    { n: "01", title: "Learn the Basics", d: "Understand how your computer, files, folders, internet, email and everyday applications actually work." },
    { n: "02", title: "Practice Yourself", d: "Work on the keyboard and computer yourself — not just watch a trainer demonstrate it." },
    { n: "03", title: "Apply the Skill", d: "Create documents, manage files, use Excel, research online, solve tasks and build small projects." },
    { n: "04", title: "Build Confidence", d: "Our goal is simple: when you sit in front of a computer alone, you should know where to start." },
  ];
  return (
    <section className="relative py-24 px-6 lg:px-10 overflow-hidden" style={{ background: PAPER }}>
      <div className="absolute -top-24 -right-24 w-80 h-80 rounded-full blur-3xl opacity-[0.10]" style={{ background: GOLD }} />
      <div className="absolute -bottom-24 -left-24 w-80 h-80 rounded-full blur-3xl opacity-[0.08]" style={{ background: SKY }} />
      <div className="relative max-w-6xl mx-auto">
        <Reveal>
          <div className="max-w-3xl mx-auto text-center">
            <Pill>More Than A Certificate</Pill>
            <h2 className="mt-4 font-bold leading-[1.1]" style={{ fontFamily: "Fraunces, serif", color: INK, fontSize: "clamp(2rem, 4vw, 3rem)" }}>
              Course kiya hai… par computer par <span style={{ color: ROYAL }}>independently</span> kaam karne ka confidence nahi?
            </h2>
            <p className="mt-5 text-[16px] leading-relaxed" style={{ color: "#5B6474" }}>
              That's exactly where we can help. Whether you're starting from zero or restarting after a previous course, Ahuja NextGen focuses on practical learning — so you don't just remember steps, you understand what you're doing.
            </p>
            <div className="mt-7 inline-flex items-center gap-2 rounded-full px-5 py-3 bg-white border" style={{ borderColor: "rgba(10,45,111,0.10)", boxShadow: "0 8px 24px -16px rgba(10,45,111,0.35)" }}>
              <span className="font-bold" style={{ color: INK }}>Learn</span><ArrowRight size={15} color={GOLD}/><span className="font-bold" style={{ color: INK }}>Practice</span><ArrowRight size={15} color={GOLD}/><span className="font-bold" style={{ color: INK }}>Apply</span><ArrowRight size={15} color={GOLD}/><span className="font-bold" style={{ color: ROYAL }}>Become Independent</span>
            </div>
          </div>
        </Reveal>
        <div className="mt-14 grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {steps.map((step, i) => (
            <Reveal key={step.n} delay={i * 80}>
              <div className="h-full rounded-2xl bg-white p-6 border hover:-translate-y-1 transition-transform" style={{ borderColor: "rgba(10,45,111,0.07)", boxShadow: "0 12px 30px -24px rgba(10,45,111,0.5)" }}>
                <div className="text-[12px] font-bold tracking-[0.14em]" style={{ color: GOLD }}>{step.n}</div>
                <h3 className="mt-3 font-bold text-[18px]" style={{ color: INK, fontFamily: "Fraunces, serif" }}>{step.title}</h3>
                <p className="mt-2.5 text-[13.5px] leading-relaxed" style={{ color: "#727C8C" }}>{step.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal delay={160}>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button variant="primary" onClick={() => setPage("admissions")}>Book Your Free 2 Demo Classes</Button>
            <span className="text-[13px]" style={{ color: "#727C8C" }}>Start from the basics. Build from there.</span>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function TrustSection() {
  const trust = [
    { icon: GraduationCap, title: "Under Experienced Educational Guidance", text: "Under the guidance of Dr. S.S. Ahuja, Retired Block Education Officer, Shahabad Markanda, with 33+ years of experience in government education and a long record of mentoring students." },
    { icon: Presentation, title: "Industry Expert Sessions", text: "Guest lectures and expert sessions can connect classroom learning with real-world technology and workplace expectations." },
    { icon: Briefcase, title: "Career & Placement Assistance", text: "Resume creation, interview preparation, career counselling and placement assistance to help learners prepare for opportunities." },
    { icon: MessageSquareText, title: "Personality Development", text: "Build communication, confidence, presentation and interview skills alongside your technical learning." },
  ];
  return (
    <section className="py-24 px-6 lg:px-10 bg-white relative overflow-hidden">
      <div className="max-w-6xl mx-auto">
        <SectionHeading eyebrow="Why Families Can Trust Us" title="Education, practical skills and career readiness — together" sub="We want learners and parents to know exactly what they are getting: guidance, hands-on practice and support beyond the classroom." />
        <div className="grid md:grid-cols-2 gap-5">
          {trust.map((item, i) => (
            <Reveal key={item.title} delay={i * 80}>
              <div className="group h-full rounded-3xl p-7 md:p-8 border transition-all duration-300 hover:-translate-y-1" style={{ borderColor: "rgba(10,45,111,0.08)", background: i === 0 ? "linear-gradient(135deg,#F7FAFF,#fff)" : "#fff", boxShadow: "0 16px 40px -32px rgba(10,45,111,0.45)" }}>
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ background: "rgba(21,101,192,0.08)" }}><item.icon size={22} color={ROYAL}/></div>
                <h3 className="mt-5 font-bold text-[20px]" style={{ color: INK, fontFamily: "Fraunces, serif" }}>{item.title}</h3>
                <p className="mt-3 text-[14px] leading-relaxed" style={{ color: "#667080" }}>{item.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal delay={160}>
          <div className="mt-8 rounded-3xl p-6 md:p-7 flex flex-col md:flex-row items-start md:items-center justify-between gap-5" style={{ background: DEEP }}>
            <div>
              <div className="text-[11px] uppercase tracking-[0.16em] font-bold" style={{ color: GOLD }}>Our Promise</div>
              <div className="mt-2 text-white font-semibold text-[20px]" style={{ fontFamily: "Fraunces, serif" }}>Certificate se pehle confidence.</div>
              <p className="mt-1.5 text-white/65 text-[13.5px]">Because learning is not complete until you can apply the skill yourself.</p>
            </div>
            <div className="flex items-center gap-2 text-white/80 text-[13px]"><CheckCircle2 size={18} color={GOLD}/> Learn. Practice. Apply. Grow.</div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function RegionalReachSection() {
  const places = ["Shahbad Markanda", "Babain", "Ladwa", "Ismailabad", "Pehowa", "Thanesar", "Nearby villages & rural communities"];
  return (
    <section className="py-20 px-6 lg:px-10" style={{ background: PAPER }}>
      <div className="max-w-6xl mx-auto rounded-[2rem] p-8 md:p-12 relative overflow-hidden" style={{ background: `linear-gradient(135deg, ${DEEP}, ${NAVY})` }}>
        <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full blur-3xl opacity-[0.12]" style={{ background: GOLD }} />
        <div className="relative grid lg:grid-cols-[1.05fr,.95fr] gap-10 items-center">
          <div>
            <Pill>Serving The Wider Region</Pill>
            <h2 className="mt-4 text-white font-bold leading-tight" style={{ fontFamily: "Fraunces, serif", fontSize: "clamp(1.9rem, 3.5vw, 2.7rem)" }}>You don't have to live in a big city to learn future-ready skills.</h2>
            <p className="mt-4 text-white/70 text-[15px] leading-relaxed">Ahuja NextGen is based in Shahbad Markanda and aims to serve learners from nearby towns, villages and rural communities across the surrounding Kurukshetra region.</p>
          </div>
          <div className="flex flex-wrap gap-2.5">
            {places.map((place) => <span key={place} className="rounded-full px-4 py-2.5 text-[13px] font-semibold text-white border border-white/15 bg-white/8">{place}</span>)}
          </div>
        </div>
      </div>
    </section>
  );
}

function LocalSEOSection() {
  return (
    <section className="py-14 px-6 lg:px-10 bg-white border-b" style={{ borderColor: "rgba(10,45,111,0.08)" }}>
      <div className="max-w-6xl mx-auto grid lg:grid-cols-[1.2fr_.8fr] gap-8 items-center">
        <div>
          <Pill>Shahbad, Haryana</Pill>
          <h2 className="mt-4 text-2xl md:text-3xl font-bold" style={{ color: INK, fontFamily: "Fraunces, serif" }}>Computer Courses & Digital Skills Training in Shahbad</h2>
          <p className="mt-3 text-[15px] leading-relaxed" style={{ color: "#5B6474" }}>Ahuja NextGen Skill & Education Academy offers practical learning paths across basic computer skills, programming, Tally, web designing, SQL, data analytics and AI/ML for students, job seekers and working professionals.</p>
        </div>
        <div className="flex flex-wrap gap-3 lg:justify-end">
          <Link href="/computer-courses-shahbad/" className="inline-flex items-center gap-2 rounded-xl px-5 py-3.5 font-semibold text-[14px]" style={{ background: GOLD, color: "#20140a" }}>Explore Computer Courses <ArrowRight size={16} /></Link>
          <Link href="/courses/" className="inline-flex items-center gap-2 rounded-xl px-5 py-3.5 font-semibold text-[14px]" style={{ color: ROYAL, border: `1.5px solid ${ROYAL}` }}>View All Courses <ArrowRight size={16} /></Link>
        </div>
      </div>
    </section>
  );
}

function HomePage({ setPage, goToEnquiry }) {
  return (
    <>
      <Hero setPage={setPage} />
      <LocalSEOSection />
      <IndependenceSection setPage={setPage} />
      <TrustSection />
      <WhyChoose />
      <CareerJourney />
      <AdmissionsStrip setPage={setPage} />
      <WhoCanJoin />
      <RegionalReachSection />
      <ProgramsOverview setPage={setPage} goToEnquiry={goToEnquiry} />
      <StatementBlock setPage={setPage} />
      <section className="py-24 px-6 lg:px-10" style={{ background: PAPER }}>
        <div className="max-w-4xl mx-auto">
          <SectionHeading eyebrow="Get In Touch" title="Talk to a career counsellor, free" />
          <ContactBlock />
        </div>
      </section>
    </>
  );
}

function AboutPage() {
  const values = [
    { t: "Practical First", d: "We teach by doing — every module ends in something you built, not just notes." },
    { t: "Industry-Anchored", d: "Curriculum reviewed against what employers are actually hiring for, today." },
    { t: "Personal Attention", d: "Small batches so no learner is a face in the crowd." },
    { t: "Integrity", d: "Honest guidance about what a course can and can't do for your career." },
  ];
  return (
    <div>
      <PageHero eyebrow="About Us" title="A modern academy, built around real careers" sub="AHUJA NEXTGEN began with a simple observation: most institutes teach syllabi, not skills. We set out to close that gap." />
      <section className="py-24 px-6 lg:px-10 bg-white">
        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-16 items-start mb-24">
          <Reveal>
            <Pill>Our Story</Pill>
            <h3 className="mt-4 text-2xl font-bold" style={{ color: INK, fontFamily: "Fraunces, serif" }}>Why we started</h3>
            <p className="mt-4 text-[15px] leading-relaxed" style={{ color: "#5B6474" }}>
              We saw too many capable students graduate with certificates but no real, demonstrable skill — and too many working professionals stuck because they never had access to structured, practical upskilling. AHUJA NEXTGEN was founded to fix both problems with one model: small batches, working professionals as trainers, and a curriculum that changes as fast as the industry does.
            </p>
          </Reveal>
          <Reveal delay={100}>
            <Pill>Vision & Mission</Pill>
            <h3 className="mt-4 text-2xl font-bold" style={{ color: INK, fontFamily: "Fraunces, serif" }}>Where we're headed</h3>
            <p className="mt-4 text-[15px] leading-relaxed" style={{ color: "#5B6474" }}>
              <strong style={{ color: INK }}>Vision:</strong> To be the region's most trusted bridge between education and employment.<br /><br />
              <strong style={{ color: INK }}>Mission:</strong> Deliver practical, affordable, industry-oriented training that turns learners into hireable professionals — regardless of where they start from.
            </p>
          </Reveal>
        </div>

        <SectionHeading eyebrow="Core Values" title="What guides every batch we run" />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-24">
          {values.map((v, i) => (
            <Reveal key={v.t} delay={i * 80}>
              <div className="rounded-2xl p-6 h-full" style={{ background: PAPER }}>
                <div className="font-semibold text-[15px]" style={{ color: INK, fontFamily: "Fraunces, serif" }}>{v.t}</div>
                <p className="mt-2 text-[13.5px] leading-relaxed" style={{ color: "#727C8C" }}>{v.d}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <SectionHeading eyebrow="Facilities" title="A learning environment built for focus" />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {[
            { icon: Laptop, t: "Modern Computer Lab", d: "Updated systems, one seat per learner during lab hours." },
            { icon: Users, t: "Smart Classrooms", d: "Projector-led sessions built for live demonstration." },
            { icon: Target, t: "Project-Based Learning", d: "Every course closes with a capstone build." },
            { icon: GraduationCap, t: "Experienced Faculty", d: "Trainers with real industry background, not just theory." },
            { icon: Clock, t: "Flexible Timings", d: "Morning, evening, and weekend batches." },
            { icon: Shield, t: "Safe, Structured Campus", d: "A focused environment for serious learners." },
          ].map((f, i) => (
            <Reveal key={f.t} delay={i * 60}>
              <div className="rounded-2xl p-6 border" style={{ borderColor: "rgba(10,45,111,0.08)" }}>
                <f.icon size={22} color={ROYAL} />
                <div className="mt-3 font-semibold text-[14.5px]" style={{ color: INK }}>{f.t}</div>
                <p className="mt-1.5 text-[13px] leading-relaxed" style={{ color: "#727C8C" }}>{f.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}

function PageHero({ eyebrow, title, sub }) {
  return (
    <section className="relative py-20 px-6 lg:px-10 overflow-hidden" style={{ background: `linear-gradient(135deg, ${DEEP}, ${NAVY})` }}>
      <div className="absolute -bottom-20 -left-20 w-72 h-72 rounded-full blur-3xl opacity-[0.18]" style={{ background: GOLD }} />
      <div className="relative max-w-4xl mx-auto text-center">
        <Reveal>
          <span className="inline-flex items-center gap-2 text-[12.5px] font-semibold text-white/90 bg-white/10 border border-white/20 rounded-full px-4 py-1.5 uppercase tracking-wide">{eyebrow}</span>
          <h1 className="mt-5 text-white font-bold leading-tight" style={{ fontFamily: "Fraunces, serif", fontSize: "clamp(1.9rem, 4vw, 2.8rem)" }}>{title}</h1>
          {sub && <p className="mt-4 text-[15.5px] text-white/75 max-w-2xl mx-auto leading-relaxed">{sub}</p>}
        </Reveal>
      </div>
    </section>
  );
}

function ProgramsPage({ goToEnquiry }) {
  const [active, setActive] = useState(0);
  return (
    <div>
      <PageHero eyebrow="Programs & Courses" title="Every course maps to a real career outcome" sub="From first-time computer users to professionals adding emerging-tech skills — pick a track and see exactly where it leads." />
      <section className="py-20 px-6 lg:px-10 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-wrap gap-2 mb-10 justify-center">
            {PROGRAM_CATS.map((p, i) => (
              <button
                key={p.t}
                onClick={() => setActive(i)}
                className="px-4 py-2 rounded-full text-[13px] font-semibold transition-colors"
                style={{ background: active === i ? ROYAL : PAPER, color: active === i ? "#fff" : "#5B6474" }}
              >
                {p.t}
              </button>
            ))}
          </div>

          <Reveal key={active}>
            <div className="rounded-3xl p-8 lg:p-10 grid lg:grid-cols-[auto,1fr] gap-8" style={{ background: PAPER }}>
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center" style={{ background: `linear-gradient(135deg, ${DEEP}, ${NAVY})` }}>
                {React.createElement(PROGRAM_CATS[active].icon, { size: 28, color: "#fff" })}
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-3">
                  <h3 className="text-2xl font-bold" style={{ color: INK, fontFamily: "Fraunces, serif" }}>{PROGRAM_CATS[active].t}</h3>
                  <span className="text-[12px] font-semibold px-3 py-1 rounded-full" style={{ background: "rgba(233,162,59,0.15)", color: "#8a5a12" }}>{PROGRAM_CATS[active].duration}</span>
                </div>
                <p className="mt-3 text-[14.5px] leading-relaxed" style={{ color: "#5B6474" }}>{PROGRAM_CATS[active].d}</p>

                {PROGRAM_CATS[active].courses.length > 0 && (
                  <div className="mt-6">
                    <div className="text-[12px] font-semibold uppercase tracking-wide mb-3" style={{ color: ROYAL }}>Courses in this Track</div>
                    <div className="flex flex-wrap gap-2">
                      {PROGRAM_CATS[active].courses.map((c) => (
                        <span key={c.name} className="flex items-center gap-2 text-[12.5px] font-medium pl-3 pr-1 py-1 rounded-full bg-white" style={{ color: INK, border: "1px solid rgba(10,45,111,0.12)" }}>
                          {c.name}
                          <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full" style={{ background: "rgba(233,162,59,0.15)", color: "#8a5a12" }}>{c.duration}</span>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div className="mt-6 grid sm:grid-cols-2 gap-8">
                  <div>
                    <div className="text-[12px] font-semibold uppercase tracking-wide mb-3" style={{ color: ROYAL }}>Learning Outcomes</div>
                    <ul className="space-y-2">
                      {PROGRAM_CATS[active].outcomes.map((o) => (
                        <li key={o} className="flex items-start gap-2 text-[13.5px]" style={{ color: "#3a4150" }}>
                          <CheckCircle2 size={15} color={ROYAL} className="mt-0.5 shrink-0" /> {o}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <div className="text-[12px] font-semibold uppercase tracking-wide mb-3" style={{ color: ROYAL }}>Career Opportunities</div>
                    <ul className="space-y-2">
                      {PROGRAM_CATS[active].careers.map((o) => (
                        <li key={o} className="flex items-start gap-2 text-[13.5px]" style={{ color: "#3a4150" }}>
                          <Briefcase size={14} color={GOLD} className="mt-0.5 shrink-0" /> {o}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <Button variant="dark" icon={false} onClick={() => goToEnquiry(PROGRAM_CATS[active].t)} className="mt-7 !px-6 !py-3">Enquire Now</Button>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="py-20 px-6 lg:px-10 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="rounded-3xl overflow-hidden grid lg:grid-cols-2" style={{ background: `linear-gradient(160deg, ${DEEP}, ${NAVY})` }}>
            <div className="p-9 lg:p-11">
              <span className="inline-flex items-center gap-2 text-[12px] font-semibold text-white/90 bg-white/10 border border-white/20 rounded-full px-4 py-1.5 uppercase tracking-wide">Foundation Classes</span>
              <h3 className="mt-4 text-white font-bold" style={{ fontFamily: "Fraunces, serif", fontSize: "clamp(1.5rem, 2.6vw, 2rem)" }}>Building Strong Foundations, Grades VI–VIII</h3>
              <p className="mt-3 text-[14px] text-white/75 leading-relaxed">Academic support in Mathematics, Science, and English — built for genuine concept clarity, not rote memorization.</p>
              <div className="mt-6 flex gap-3">
                {["Mathematics", "Science", "English"].map((s) => (
                  <span key={s} className="flex-1 text-center rounded-lg py-2.5 text-[13px] font-semibold text-white" style={{ background: "rgba(255,255,255,0.12)" }}>{s}</span>
                ))}
              </div>
            </div>
            <div className="p-9 lg:p-11" style={{ background: "rgba(255,255,255,0.06)" }}>
              <div className="text-[12px] font-semibold uppercase tracking-wide text-white/70 mb-4">Why Parents Choose Our Foundation Classes</div>
              <ul className="space-y-3">
                {[
                  "Academic support by experienced, dedicated teachers",
                  "Concept-based learning for strong fundamentals",
                  "Aligned with the latest school curriculum",
                  "Evening classes after school hours",
                  "Regular assessments & doubt-solving sessions",
                ].map((p) => (
                  <li key={p} className="flex items-start gap-2.5 text-[13.5px] text-white/85">
                    <CheckCircle2 size={16} color={GOLD} className="mt-0.5 shrink-0" /> {p}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function CareerServicesPage() {
  const services = [
    { icon: Award, t: "Resume Building", d: "One-on-one help turning your projects and coursework into a resume that gets shortlisted." },
    { icon: MessageSquareText, t: "Interview Preparation", d: "Structured prep covering technical rounds, HR rounds, and common curveball questions." },
    { icon: Users, t: "Career Counselling", d: "Individual sessions to map your background to the right track and realistic timelines." },
    { icon: Briefcase, t: "Placement Guidance", d: "Introductions and guidance toward hiring partners and open roles matching your skill level." },
    { icon: Target, t: "Mock Interviews", d: "Practice interviews with feedback you can act on before the real one." },
    { icon: GraduationCap, t: "Professional Development", d: "Workshops on workplace etiquette, time management, and professional communication." },
    { icon: MessageSquareText, t: "Communication Skills", d: "Spoken English and presentation practice for interview and workplace confidence." },
    { icon: Sparkles, t: "Leadership Skills", d: "Foundational leadership and teamwork training for early-career professionals." },
  ];
  return (
    <div>
      <PageHero eyebrow="Career Services" title="Support that doesn't stop at certification" sub="A course teaches the skill. Our career services make sure that skill turns into an offer." />
      <section className="py-20 px-6 lg:px-10 bg-white">
        <div className="max-w-6xl mx-auto grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {services.map((s, i) => (
            <Reveal key={s.t} delay={i * 60}>
              <div className="rounded-2xl p-6 h-full" style={{ background: PAPER }}>
                <div className="w-11 h-11 rounded-xl flex items-center justify-center mb-4" style={{ background: `linear-gradient(135deg, ${DEEP}, ${NAVY})` }}>
                  <s.icon size={19} color="#fff" />
                </div>
                <div className="font-semibold text-[14.5px]" style={{ color: INK }}>{s.t}</div>
                <p className="mt-2 text-[13px] leading-relaxed" style={{ color: "#727C8C" }}>{s.d}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
      <CareerJourney />
    </div>
  );
}

function AdmissionsPage({ initialCourse = "" }) {
  const steps = ["Book a free demo class", "Meet a career counsellor", "Choose your program", "Submit documents & enrol", "Start learning"];
  const faqs = [
    { q: "Are the demo classes really free?", a: "Yes — every applicant gets two free demo classes before committing to a program." },
    { q: "What documents do I need?", a: "A valid photo ID, latest educational certificate, and two passport-size photographs." },
    { q: "Do you offer scholarships?", a: "Merit and need-based fee concessions are available; ask your counsellor during enrolment." },
    { q: "Can working professionals attend?", a: "Yes, weekend and evening batches are designed specifically for working professionals." },
  ];
  const [openFaq, setOpenFaq] = useState(null);
  return (
    <div>
      <PageHero eyebrow="Admissions" title="Your seat is closer than you think" sub="Free counselling, transparent fees, and a simple five-step process." />
      <section className="py-20 px-6 lg:px-10 bg-white">
        <div className="max-w-5xl mx-auto">
          <SectionHeading eyebrow="Process" title="Five steps from enquiry to enrolled" center={false} />
          <div className="grid sm:grid-cols-5 gap-4 mb-20">
            {steps.map((s, i) => (
              <Reveal key={s} delay={i * 80}>
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto rounded-full flex items-center justify-center font-bold text-white" style={{ background: `linear-gradient(135deg, ${DEEP}, ${NAVY})`, fontFamily: "Fraunces, serif" }}>{i + 1}</div>
                  <p className="mt-3 text-[13px] leading-snug" style={{ color: "#5B6474" }}>{s}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-10 mb-20">
            <Reveal>
              <div className="rounded-2xl p-7 h-full" style={{ background: PAPER }}>
                <div className="font-semibold text-[15px] mb-4" style={{ color: INK }}>Documents Required</div>
                {["Valid Photo ID (Aadhaar/School ID)", "Latest Educational Certificate", "2 Passport-size Photographs"].map((d) => (
                  <div key={d} className="flex items-center gap-2 text-[13.5px] py-1.5" style={{ color: "#3a4150" }}><CheckCircle2 size={15} color={ROYAL} /> {d}</div>
                ))}
              </div>
            </Reveal>
            <Reveal delay={100}>
              <div className="rounded-2xl p-7 h-full text-white" style={{ background: `linear-gradient(135deg, ${DEEP}, ${NAVY})` }}>
                <div className="font-semibold text-[15px] mb-4">Current Offers</div>
                {["15% Early Bird Discount", "2 Free Demo Classes", "Free Career Counselling", "Merit-based Scholarships"].map((d) => (
                  <div key={d} className="flex items-center gap-2 text-[13.5px] py-1.5 text-white/90"><Star size={14} fill={GOLD} color={GOLD} /> {d}</div>
                ))}
              </div>
            </Reveal>
          </div>

          <SectionHeading eyebrow="FAQ" title="Common admissions questions" center={false} />
          <div className="space-y-3 mb-20">
            {faqs.map((f, i) => (
              <div key={f.q} className="rounded-xl border overflow-hidden" style={{ borderColor: "rgba(10,45,111,0.1)" }}>
                <button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="w-full flex items-center justify-between px-5 py-4 text-left">
                  <span className="font-medium text-[14px]" style={{ color: INK }}>{f.q}</span>
                  <ChevronDown size={18} color={ROYAL} style={{ transform: openFaq === i ? "rotate(180deg)" : "none", transition: "transform .2s" }} />
                </button>
                {openFaq === i && <p className="px-5 pb-4 text-[13.5px] leading-relaxed" style={{ color: "#727C8C" }}>{f.a}</p>}
              </div>
            ))}
          </div>

          <SectionHeading eyebrow="Fee Enquiry" title="Get exact fees for your chosen program" center={false} />
          {initialCourse && (
            <div className="mb-5 flex items-center gap-2 text-[13.5px] font-medium rounded-lg px-4 py-3" style={{ background: "rgba(21,101,192,0.08)", color: ROYAL }}>
              <CheckCircle2 size={16} /> Pre-selected from your click: <strong>{initialCourse}</strong>
            </div>
          )}
          <ContactBlock initialCourse={initialCourse} />
        </div>
      </section>
    </div>
  );
}

function ContactPage() {
  return (
    <div>
      <PageHero eyebrow="Contact" title="Let's talk about your next step" sub="Call, message, or drop by — a real counsellor, not a chatbot, will get back to you." />
      <section className="py-20 px-6 lg:px-10 bg-white">
        <div className="max-w-5xl mx-auto">
          <ContactBlock />
        </div>
      </section>
    </div>
  );
}

/* ---------------- WHATSAPP FLOATING BUTTON ---------------- */
function WhatsAppButton() {
  const phone = "919034640741"; // primary WhatsApp number, country code + number, no spaces or +
  const message = encodeURIComponent("Hi! I'm interested in courses at Ahuja NextGen. Please share more details.");
  return (
    <a
      href={`https://wa.me/${phone}?text=${message}`}
      target="_blank"
      rel="noopener noreferrer"
      className="hidden sm:flex fixed bottom-6 right-6 z-[60] items-center gap-2.5 rounded-full pl-4 pr-5 py-3.5 text-white font-semibold text-[14px] shadow-2xl hover:-translate-y-1 transition-transform duration-200"
      style={{ background: "#25D366", boxShadow: "0 10px 28px -6px rgba(37,211,102,0.6)" }}
      aria-label="Chat with us on WhatsApp"
    >
      <MessageCircle size={22} fill="#fff" color="#25D366" />
      <span className="hidden sm:inline">Chat on WhatsApp</span>
    </a>
  );
}

function MobileActionBar({ onOpenDemo }) {
  return (
    <div className="sm:hidden fixed bottom-0 inset-x-0 z-[70] border-t border-slate-200 bg-white/95 backdrop-blur-xl px-3 pt-2.5 pb-[calc(0.65rem+env(safe-area-inset-bottom))] shadow-[0_-10px_30px_-18px_rgba(10,45,111,0.45)]">
      <div className="mx-auto grid max-w-md grid-cols-2 gap-2">
        <a href="tel:+919034640741" className="flex min-h-11 items-center justify-center gap-2 rounded-xl border border-[#0A2D6F]/15 bg-white px-3 text-sm font-bold text-[#0A2D6F]" aria-label="Call Ahuja NextGen">
          <Phone size={17} /> Call Us
        </a>
        <button onClick={onOpenDemo} className="flex min-h-11 items-center justify-center gap-2 rounded-xl bg-[#E9A23B] px-3 text-sm font-bold text-[#20140a]" aria-label="Book a free demo class">
          <GraduationCap size={17} /> Free Demo
        </button>
      </div>
    </div>
  );
}

/* ================= APP ================= */
export default function App() {
  const [page, setPage] = useState("home");
  const [enquiryCourse, setEnquiryCourse] = useState("");
  const [demoOpen, setDemoOpen] = useState(false);
  useEffect(() => { window.scrollTo(0, 0); }, [page]);

  // Every "Enquire Now" button in the app calls this — it carries the exact
  // course/track clicked straight into the Admissions enquiry form, pre-selected.
  const goToEnquiry = (courseName) => {
    setEnquiryCourse(courseName);
    setPage("admissions");
  };

  const pages = {
    home: <HomePage setPage={setPage} goToEnquiry={goToEnquiry} />,
    about: <AboutPage />,
    programs: <ProgramsPage goToEnquiry={goToEnquiry} />,
    career: <CareerServicesPage />,
    admissions: <AdmissionsPage initialCourse={enquiryCourse} />,
    contact: <ContactPage />,
  };

  return (
    <div style={{ fontFamily: "Inter, sans-serif" }} className="min-h-screen bg-white relative">
      {/* Uniform film-grain texture over the entire site — one consistent premium detail instead of scattered per-section effects */}
      <div
        className="fixed inset-0 pointer-events-none z-[999]"
        style={{ backgroundImage: `url(${GRAIN})`, backgroundSize: "128px 128px", opacity: 0.035, mixBlendMode: "multiply" }}
      />
      <Navbar page={page} setPage={setPage} onOpenDemo={() => setDemoOpen(true)} />
      {pages[page]}
      <Footer setPage={setPage} />
      <WhatsAppButton />
      <MobileActionBar onOpenDemo={() => setDemoOpen(true)} />
      <DemoModal open={demoOpen} onClose={() => setDemoOpen(false)} />
    </div>
  );
}
