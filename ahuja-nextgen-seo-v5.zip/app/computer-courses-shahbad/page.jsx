import Link from "next/link";

export const metadata = {
  title: "Computer Courses in Shahbad, Haryana",
  description:
    "Explore computer courses in Shahbad at Ahuja NextGen Skill & Education Academy. Learn Python, C/C++, SQL, Tally, web designing, data analytics, AI/ML and practical digital skills.",
  alternates: { canonical: "/computer-courses-shahbad/" },
  openGraph: {
    title: "Computer Courses in Shahbad | Ahuja NextGen",
    description: "Practical computer and digital skills training in Shahbad, Haryana.",
    url: "https://ahujanextgen.com/computer-courses-shahbad/",
  },
};

const courses = [
  ["Basic Computer Course", "Build strong fundamentals in computers, internet, office productivity and everyday digital skills.", "/courses/basic-computer/"],
  ["Python Course", "Learn Python through practical programming exercises and projects.", "/courses/python/"],
  ["C & C++ Programming", "Develop programming fundamentals, problem-solving and coding skills.", "/courses/c-programming/"],
  ["SQL Course", "Learn databases, queries and practical SQL skills for technology and analytics roles.", "/courses/sql/"],
  ["Tally Course", "Build practical accounting and business software skills with Tally.", "/courses/tally/"],
  ["Web Designing", "Learn HTML, CSS and the fundamentals of creating modern websites.", "/courses/web-designing/"],
  ["Data Analytics", "Build practical skills in data analysis, reporting and business insights.", "/courses/data-analytics/"],
  ["AI & Machine Learning", "Understand practical applications of AI and machine learning through guided learning.", "/courses/ai-ml/"],
];

const faqs = [
  ["What computer courses are available in Shahbad?", "Ahuja NextGen offers computer and digital skills programs including basic computer skills, Python, C/C++, SQL, Tally, web designing, data analytics and AI/ML. Availability and batches can change, so contact the academy for the current schedule."],
  ["Who can join computer courses at Ahuja NextGen?", "Programs are designed for different learner groups, including school students, college students, job seekers and working professionals. The right course depends on your current level and goal."],
  ["Where is Ahuja NextGen located?", "Ahuja NextGen Skill & Education Academy is located in Shahbad, Haryana 136135. Contact the academy to confirm the current address, timings and batch availability before visiting."],
  ["Can I enquire about a course before enrolling?", "Yes. You can contact Ahuja NextGen for course details, eligibility, schedule and an enrolment discussion before deciding."],
];

export default function ComputerCoursesShahbad() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map(([q, a]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: a } })),
  };
  const breadcrumb = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: "https://ahujanextgen.com/" },
      { "@type": "ListItem", position: 2, name: "Computer Courses in Shahbad", item: "https://ahujanextgen.com/computer-courses-shahbad/" },
    ],
  };
  return (
    <main className="min-h-screen bg-white text-slate-900">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumb) }} />
      <header className="bg-[#050D1F] text-white">
        <div className="mx-auto max-w-6xl px-6 py-5 flex items-center justify-between gap-4">
          <Link href="/" className="font-bold text-lg">AHUJA NEXTGEN</Link>
          <Link href="/" className="rounded-xl bg-[#E9A23B] px-4 py-2 text-sm font-semibold text-[#20140a]">Back to Academy</Link>
        </div>
      </header>
      <section className="bg-gradient-to-b from-[#050D1F] to-[#0A2D6F] text-white">
        <div className="mx-auto max-w-6xl px-6 py-16 md:py-24">
          <nav aria-label="Breadcrumb" className="mb-5 text-sm text-blue-200"><Link href="/">Home</Link><span className="mx-2">/</span><span>Computer Courses in Shahbad</span></nav><p className="mb-4 text-sm font-semibold uppercase tracking-[0.16em] text-blue-200">Shahbad, Haryana</p>
          <h1 className="max-w-4xl text-4xl font-bold leading-tight md:text-6xl">Computer Courses in Shahbad</h1>
          <p className="mt-6 max-w-3xl text-lg leading-8 text-blue-50">Learn practical computer, programming, AI, data analytics and digital skills at Ahuja NextGen Skill & Education Academy. Programs are designed for students, college learners, job seekers and working professionals.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="tel:+919034640741" className="rounded-xl bg-[#E9A23B] px-5 py-3 font-semibold text-[#20140a]">Call the Academy</a>
            <a href="https://wa.me/919034640741" className="rounded-xl border border-white/40 px-5 py-3 font-semibold text-white">WhatsApp Enquiry</a>
          </div>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-6 py-16">
        <div className="max-w-3xl">
          <p className="text-sm font-bold uppercase tracking-[0.14em] text-[#1565C0]">Ahuja NextGen Skill & Education Academy</p>
          <h2 className="mt-3 text-3xl font-bold md:text-4xl">Practical computer and digital skills training in Shahbad</h2>
          <p className="mt-4 leading-7 text-slate-600">If you are looking for a computer institute in Shahbad, Ahuja NextGen provides structured learning across foundational computer skills, programming, business software, web technologies, analytics and AI. Choose a course based on your current level and career or academic goal.</p>
        </div>
        <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {courses.map(([name, desc, href]) => (
            <article key={name} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <h3 className="text-xl font-bold">{name}</h3>
              <p className="mt-3 text-sm leading-6 text-slate-600">{desc}</p>
              <Link href={href} className="mt-5 inline-block font-semibold text-[#1565C0]">View course →</Link>
            </article>
          ))}
        </div>
      </section>
      <section className="bg-[#F6F4EF]">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <h2 className="text-3xl font-bold">Why learn with Ahuja NextGen?</h2>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {[["Practical learning", "Focus on skills that learners can apply in academic, professional and project settings."], ["Multiple skill paths", "Move from basic computer skills into programming, analytics, AI or web development as your goals evolve."], ["Local learning", "Study with a local academy in Shahbad and discuss your learning path directly with the team."]].map(([title, text]) => <div key={title} className="rounded-2xl bg-white p-6"><h3 className="font-bold text-lg">{title}</h3><p className="mt-2 text-slate-600 leading-6">{text}</p></div>)}
          </div>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-6 py-16">
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="rounded-3xl bg-[#050D1F] p-8 text-white">
            <p className="text-sm font-bold uppercase tracking-[0.14em] text-blue-200">Learn → Practice → Apply → Grow</p>
            <h2 className="mt-3 text-3xl font-bold">Certificate se pehle confidence.</h2>
            <p className="mt-4 leading-7 text-white/75">The academy's learning approach is built around understanding concepts, practising with tools, applying skills to useful tasks and building confidence to work independently.</p>
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              {["Understand the fundamentals", "Practise with tools", "Apply through exercises and projects", "Build confidence for real work"].map((item) => <div key={item} className="rounded-xl border border-white/10 bg-white/5 p-4 text-sm text-white/85">{item}</div>)}
            </div>
          </div>
          <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
            <p className="text-sm font-bold uppercase tracking-[0.14em] text-[#1565C0]">Choosing a course</p>
            <h2 className="mt-3 text-3xl font-bold">Which computer course should you choose?</h2>
            <p className="mt-4 leading-7 text-slate-600">Start with your goal rather than the course name. Beginners may need foundational computer skills; learners interested in programming can explore Python or C/C++; data-focused learners can explore SQL and Data Analytics; business and accounting learners can explore Tally; and technology learners can explore Web Designing or AI/ML.</p>
            <p className="mt-4 leading-7 text-slate-600">For the current syllabus, batch timing, eligibility and fees, contact Ahuja NextGen before enrolling.</p>
          </div>
        </div>
      </section>
      <section className="mx-auto max-w-4xl px-6 py-16">
        <h2 className="text-3xl font-bold">Frequently Asked Questions</h2>
        <div className="mt-8 space-y-4">
          {faqs.map(([q, a]) => <details key={q} className="rounded-2xl border border-slate-200 p-5"><summary className="cursor-pointer font-semibold">{q}</summary><p className="mt-3 leading-7 text-slate-600">{a}</p></details>)}
        </div>
      </section>
      <footer className="bg-[#050D1F] text-white">
        <div className="mx-auto max-w-6xl px-6 py-10 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div><p className="font-bold">Ahuja NextGen Skill & Education Academy</p><p className="mt-1 text-sm text-white/70">Shahbad, Haryana 136135</p></div>
          <Link href="/" className="font-semibold text-[#E9A23B]">Visit the main website →</Link>
        </div>
      </footer>
    </main>
  );
}
