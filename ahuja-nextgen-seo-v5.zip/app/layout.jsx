import "./globals.css";

const siteUrl = "https://ahujanextgen.com";
const businessName = "Ahuja NextGen Skill & Education Academy";
const primaryPhone = "+91-90346-40741";
const instagram = "https://www.instagram.com/ahuja_nextgen/";

export const viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#0A2D6F",
};

export const metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Computer Courses in Shahbad | Ahuja NextGen Skill & Education Academy",
    template: "%s | Ahuja NextGen",
  },
  description:
    "Ahuja NextGen Skill & Education Academy provides practical computer and digital skills training in Shahbad, Haryana, including Basic Computer, Python, Tally, Data Analytics, AI/ML, Web Designing, SQL and programming.",
  applicationName: businessName,
  authors: [{ name: businessName, url: siteUrl }],
  creator: businessName,
  publisher: businessName,
  icons: { icon: "/logo.webp", apple: "/logo.webp" },
  keywords: [
    "computer courses in Shahbad",
    "computer institute in Shahbad",
    "computer classes in Shahbad",
    "computer training in Shahbad",
    "Python course in Shahbad",
    "Tally course in Shahbad",
    "AI ML course in Shahbad",
    "data analytics course in Shahbad",
    "web designing course in Shahbad",
    "Ahuja NextGen",
  ],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    url: siteUrl + "/",
    siteName: businessName,
    title: "Computer Courses in Shahbad | Ahuja NextGen",
    description:
      "Practical computer, programming, AI, data analytics and digital skills training in Shahbad, Haryana.",
    locale: "en_IN",
    images: [{ url: "/logo.webp", width: 512, height: 512, alt: businessName }],
  },
  twitter: {
    card: "summary",
    title: "Computer Courses in Shahbad | Ahuja NextGen",
    description: "Practical computer and digital skills training in Shahbad, Haryana.",
    images: ["/logo.webp"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
};

export default function RootLayout({ children }) {
  const graph = [
    {
      "@type": ["EducationalOrganization", "LocalBusiness"],
      "@id": siteUrl + "/#academy",
      name: businessName,
      alternateName: "Ahuja NextGen",
      url: siteUrl + "/",
      logo: siteUrl + "/logo.webp",
      description:
        "Skill and education academy offering computer courses and digital skills training in Shahbad, Haryana.",
      telephone: primaryPhone,
      email: "ahujanextgen@gmail.com",
      address: {
        "@type": "PostalAddress",
        streetAddress: "Ekta Vihar, Near City Heart School",
        addressLocality: "Shahbad Markanda",
        addressRegion: "Haryana",
        postalCode: "136135",
        addressCountry: "IN",
      },
      geo: { "@type": "GeoCoordinates", latitude: 30.163771, longitude: 76.866365 },
      hasMap: "https://maps.google.com/?q=30.163771,76.866365",
      areaServed: [
        { "@type": "City", name: "Shahbad" },
        { "@type": "AdministrativeArea", name: "Kurukshetra district" },
      ],
      sameAs: [instagram],
      knowsAbout: [
        "Computer education",
        "Basic computer skills",
        "Programming",
        "Python",
        "C and C++",
        "SQL",
        "Tally",
        "Web designing",
        "Data analytics",
        "Artificial intelligence",
        "Machine learning",
        "Digital skills",
      ],
      hasOfferCatalog: {
        "@type": "OfferCatalog",
        name: "Computer and Digital Skills Courses",
        itemListElement: [
          "Basic Computer Course",
          "Python Course",
          "C & C++ Programming Course",
          "SQL Course",
          "Tally Course",
          "Web Designing Course",
          "Data Analytics Course",
          "AI & Machine Learning Course",
        ].map((name) => ({
          "@type": "Offer",
          itemOffered: { "@type": "Course", name },
        })),
      },
    },
    {
      "@type": "Organization",
      "@id": siteUrl + "/#organization",
      name: businessName,
      alternateName: "Ahuja NextGen",
      url: siteUrl + "/",
      logo: siteUrl + "/logo.webp",
      sameAs: [instagram],
    },
    {
      "@type": "Person",
      "@id": siteUrl + "/#dr-ss-ahuja",
      name: "Dr. S.S. Ahuja",
      jobTitle: "Retired Block Education Officer",
      description:
        "Retired Block Education Officer, Shahabad Markanda, with 33+ years of experience in government education and a record of mentoring students.",
      worksFor: { "@id": siteUrl + "/#academy" },
    },
    {
      "@type": "WebSite",
      "@id": siteUrl + "/#website",
      url: siteUrl + "/",
      name: businessName,
      publisher: { "@id": siteUrl + "/#organization" },
      inLanguage: "en-IN",
    },
  ];

  return (
    <html lang="en-IN">
      <body>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({ "@context": "https://schema.org", "@graph": graph }),
          }}
        />
        {children}
      </body>
    </html>
  );
}
